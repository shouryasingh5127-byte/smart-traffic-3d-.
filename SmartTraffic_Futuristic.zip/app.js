// app.js - Futuristic site with 3D-like drone simulation and joysticks
(() => {
  const AUTH = { user: 'shourya', pass: '2105' };
  const DRONE_PASS = '210510';

  // screens
  const screens = { welcome: document.getElementById('welcome'), dashboard: document.getElementById('dashboard'), drone: document.getElementById('drone') };
  const showScreen = (n)=>{ Object.values(screens).forEach(s=>s.classList.remove('active')); screens[n].classList.add('active'); window.scrollTo(0,0); }

  // login
  const inputUser = document.getElementById('username'), inputPass = document.getElementById('password');
  const btnLogin = document.getElementById('btn-login'), btnSample = document.getElementById('btn-sample');
  const loginError = document.getElementById('login-error');
  btnLogin.addEventListener('click', ()=>{
    if(inputUser.value.trim().toLowerCase() === AUTH.user && inputPass.value.trim() === AUTH.pass){
      loginError.textContent=''; showScreen('dashboard');
    } else { loginError.textContent='Invalid username or password'; }
  });
  btnSample.addEventListener('click', ()=>{ inputUser.value='shourya'; inputPass.value='2105'; btnLogin.click(); });

  // dashboard actions
  document.getElementById('btn-logout').addEventListener('click', ()=> showScreen('welcome'));
  document.getElementById('btn-go-drone').addEventListener('click', ()=> showScreen('drone'));
  document.getElementById('btn-open-cross').addEventListener('click', ()=> {
    const box = document.querySelector('.camera-card .camera-box');
    box.textContent = 'Pedestrian crossing enabled (simulated)';
    setTimeout(()=>box.textContent='No live feed configured',4000);
  });

  // Alfred open: try app via intent (Android), fallback to Play Store
  document.getElementById('btn-open-alfred').addEventListener('click', ()=>{
    const packageName = 'com.ivuu';
    const intentURI = 'intent://#Intent;package='+packageName+';end';
    // attempt to open Alfred app
    window.location = intentURI;
    // fallback to Play Store after short delay
    setTimeout(()=>{ window.open('https://play.google.com/store/apps/details?id='+packageName,'_blank'); },1200);
  });

  // drone screen unlock
  const unlockBtn = document.getElementById('btn-unlock-drone'), dronePassInput = document.getElementById('drone-pass');
  const dronePanel = document.getElementById('drone-panel'), droneError = document.getElementById('drone-error');
  unlockBtn.addEventListener('click', ()=>{
    if(dronePassInput.value.trim()===DRONE_PASS){ droneError.textContent=''; dronePanel.classList.remove('hidden'); document.querySelector('.panel.pad').classList.add('hidden'); initDrone(); }
    else droneError.textContent='Wrong drone password';
  });
  document.getElementById('btn-back-dashboard').addEventListener('click', ()=> showScreen('dashboard'));

  // simple drone sim and joystick
  const canvas = document.getElementById('drone-canvas'), ctx = canvas.getContext('2d');
  let W = canvas.width, H = canvas.height;
  const drone = { x: W/2, y: H/2, vx:0, vy:0, ang:0, alt:0, batt:100, state:'LANDED', speed:3 };

  function initDrone(){
    // setup virtual joysticks using basic pointer events
    const left = document.getElementById('joystick-left'), right = document.getElementById('joystick-right');
    setupJoystick(left, (dx,dy)=>{ // left joystick - altitude/yaw
      drone.alt += -dy*0.02; if(drone.alt<0) drone.alt=0; drone.ang += dx*0.02;
    });
    setupJoystick(right, (dx,dy)=>{ // right joystick - horizontal movement
      drone.vx += dx*0.05; drone.vy += dy*0.05;
    });

    document.getElementById('btn-takeoff').addEventListener('click', ()=>{ drone.state='TAKEOFF'; drone.alt=80; });
    document.getElementById('btn-land').addEventListener('click', ()=>{ drone.state='LAND'; drone.alt=0; drone.vx=drone.vy=0; });
    requestAnimationFrame(loop);
  }

  function setupJoystick(el, onmove){
    let active=false, startX=0, startY=0;
    el.addEventListener('pointerdown', (e)=>{ active=true; startX=e.clientX; startY=e.clientY; el.setPointerCapture(e.pointerId); });
    el.addEventListener('pointermove', (e)=>{ if(!active) return; const dx=(e.clientX-startX), dy=(e.clientY-startY); onmove(dx,dy); });
    el.addEventListener('pointerup', (e)=>{ active=false; el.releasePointerCapture(e.pointerId); });
    el.addEventListener('pointercancel', ()=>{ active=false; });
  }

  function loop(){
    // physics
    drone.vx *= 0.97; drone.vy *= 0.97;
    drone.x += drone.vx; drone.y += drone.vy;
    if(drone.x<20) drone.x=20; if(drone.x>W-20) drone.x=W-20;
    if(drone.y<20) drone.y=20; if(drone.y>H-20) drone.y=H-20;
    // draw
    ctx.clearRect(0,0,W,H);
    // ground
    ctx.fillStyle='#0b0c0d'; ctx.fillRect(0,0,W,H);
    // shadow
    const shadowSize = 30 + Math.max(0,100-drone.alt)*0.2;
    ctx.fillStyle='rgba(0,0,0,0.45)'; ctx.beginPath(); ctx.ellipse(drone.x, drone.y+28, shadowSize, shadowSize*0.4, 0, 0, Math.PI*2); ctx.fill();
    // drone body with 3D effect
    const g = ctx.createLinearGradient(drone.x-20,drone.y-20,drone.x+20,drone.y+20);
    g.addColorStop(0,'#0ff7c3'); g.addColorStop(1,'#00a07a');
    ctx.fillStyle=g; ctx.beginPath(); ctx.ellipse(drone.x, drone.y, 22, 16, drone.ang, 0, Math.PI*2); ctx.fill();
    // rotors
    ctx.fillStyle='#ddd'; ctx.fillRect(drone.x-44, drone.y-28, 12,4); ctx.fillRect(drone.x+32, drone.y-28, 12,4);
    ctx.fillRect(drone.x-44, drone.y+24, 12,4); ctx.fillRect(drone.x+32, drone.y+24, 12,4);
    // altitude text
    document.getElementById('drone-alt').textContent = 'Altitude: ' + Math.max(0,Math.round(drone.alt));
    document.getElementById('drone-state').textContent = 'State: ' + drone.state;
    document.getElementById('drone-batt').textContent = 'Battery: ' + Math.max(0,Math.round(drone.batt)) + '%';
    requestAnimationFrame(loop);
  }

  // resize canvas responsive
  window.addEventListener('resize', ()=>{ const r = canvas.getBoundingClientRect(); W = canvas.width = Math.min(900, Math.floor(r.width)); H = canvas.height = Math.floor(r.width*0.55); })

  // init canvas size initially
  (function(){ const r = canvas.getBoundingClientRect(); W = canvas.width = Math.min(900, Math.floor(window.innerWidth*0.8)); H = canvas.height = Math.floor(W*0.55); })();

})();